export interface User {
    uid:string;
    firstname:string;
    lastname:string;
    selectedTitle:string;
    mobile:string;
    email:string;
    address:string;
    password:string;
    confirmPassword:string;
    createdAt:any;
}