export interface Product {
    id: string; 
    name: string; 
    price: number; 
    image: string; 
    quantity: number; 
    totalPrice: number; 
  }
  
  export const products: Product[] = [];
  
  